#include <iostream>
#include <fstream>
#include "menu.h"
using  namespace  std;

int main()
{
    Node<int> *queue = nullptr;

    chooseFuction(queue);

    return 0;
}
